# Visual report template

When the user accepts the visual report, copy the HTML below into a new `.html` file, replace **only** the JSON inside `<script id="REPORT_DATA">` with this decision's data (same keys), and deliver the file (or publish it as an artifact). Keep everything else unchanged: the Crew mascots are drawn inline, so the file works offline. It adapts to phones, print and reduced motion, follows the device's light/dark mode by default with a ☀️/🖥️/🌙 switch for the reader, and has a "Copy summary" button for pasting into chat or email.

Keys:
- `lang`: `en` | `es` (use the user's language; labels switch automatically).
- `title`, `date`, `verdict`, `confidence` (0–10).
- `tone`: `go` (do it) | `stop` (don't) | `test` (do it like this / first find out).
- `agreement`, `disagreement`, `key_assumption`, `next_step`, `kill_criterion`.
- `precedents[]`: `type` failure|survivor, `name`, `years`, `note`, `match[]`, `miss[]`.
- `advisors[]`: `role`, `name`, `position` for|against|depends, `line`, `opinion` true|false.
  `role` picks the mascot: `devil` (Nix), `first` (Root), `expansion` (Nova), `outsider` (Pip), `executor` (Tack), `finance` (Penny), `risk` (Lex), `customer` (Mo), `technical` (Bolt), `investor` (Cap), `people` (Kin), `scout` (Juno, idea mode). The chair is Vera.
- `premortem[]`: objects with `cause` and `signal` (the early warning to watch). Plain strings still work.

Context, so the report makes sense to someone who wasn't in the conversation:
- `context`: `prompt` (the user's plan, close to their own words), `prepared_by`, `for` (meeting, person or purpose). Ask for `prepared_by`/`for` only if the user wants to share it; otherwise omit them.
- `facts[]`: `kind` given (the user said it) | assumed (you assumed it; say so) | external (checked against a source), `text`.
- `status`: `draft` | `decided` | `dropped` (default `draft`). `review_date`: the date in the kill criterion.
- `sources[]`: `title`, `url` for every external fact and precedent. Precedents may also carry their own `url`.
Never put a figure under `given` that the user didn't give.

```html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<meta name="color-scheme" content="light dark">
<title>Been There · Report</title>
<style>
  /*
    VOICE   Friendly but serious: a decision memo with characters.
    IDEA    A one-page decision brief: verdict and actions first, evidence after.
    PICTURE The Crew mascots and the confidence ring.
    COLOUR  Lavender ground, ink text; green/amber/red only for for/depends/against, all >= 4.5:1.
    LAYOUT  Inverted pyramid: verdict, actions, context, evidence, reference.
  */
  :root{
    color-scheme:light dark;
    --bg:light-dark(#F7F4FF,#14111F);--card:light-dark(#FFFFFF,#1F1A2E);--card-2:light-dark(#FBFAFF,#262038);
    --ink:light-dark(#231C3A,#F1EDFB);--muted:light-dark(#625B7A,#B4ACCB);--line:light-dark(#E7E0F7,#332B48);
    --violet:light-dark(#5B3FD6,#B7A6FF);--violet-soft:light-dark(#EFEAFF,#2C2547);
    --go:light-dark(#127A50,#6FD9A8);--go-soft:light-dark(#E3F7EE,#17352A);
    --stop:light-dark(#C0283B,#FF8F9C);--stop-soft:light-dark(#FDE8EB,#3A1C24);
    --test:light-dark(#8A5A00,#FFC861);--test-soft:light-dark(#FFF4DC,#3A2E12);
    --ring-go:#1FA971;--ring-stop:#E2475A;--ring-test:#E8A21B;
    --r:22px;--shadow:0 1px 2px rgba(35,28,58,.05),0 10px 28px -16px rgba(35,28,58,.25);
  }
  :root[data-theme=light]{color-scheme:light}:root[data-theme=dark]{color-scheme:dark}
  *{box-sizing:border-box;min-width:0}
  html{-webkit-text-size-adjust:100%;scroll-padding-top:72px;overflow-x:clip}
  body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",Inter,Roboto,sans-serif;padding:24px 16px 56px;overflow-x:clip}
  body::before{content:"";position:fixed;z-index:-1;inset:-30% -10% auto auto;width:520px;height:520px;border-radius:50%;background:radial-gradient(closest-side,light-dark(#E2D8FF,#2A2150),transparent);pointer-events:none}
  main{max-width:960px;margin:0 auto;display:flex;flex-direction:column;gap:18px}
  h1,h2,h3,.display{font-family:ui-rounded,"SF Pro Rounded","Nunito","Segoe UI",sans-serif}
  a{color:var(--violet)}
  :focus-visible{outline:3px solid var(--violet);outline-offset:2px;border-radius:6px}
  .skip{position:absolute;left:-999px;top:8px}.skip:focus{left:16px;background:var(--card);padding:8px 12px;z-index:9}
  .sr{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0 0 0 0);white-space:nowrap}
  .ico{width:20px;height:20px;flex:none;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}

  /* header */
  .brand{display:flex;align-items:center;gap:10px;font-weight:800;font-size:15px}
  .brand .dot{width:10px;height:10px;border-radius:50%;background:#E2475A;box-shadow:0 0 0 4px light-dark(#FDE8EB,#3A1C24)}
  .brand a{color:inherit;text-decoration:none}
  .brand time{margin-left:auto;font-weight:600;color:var(--muted);font-size:14px}
  .theme{display:inline-flex;gap:2px;background:var(--card);border:1px solid var(--line);border-radius:999px;padding:3px;margin-left:10px}
  .theme button{border:0;background:none;color:var(--muted);width:40px;height:36px;border-radius:999px;display:grid;place-items:center;cursor:pointer;padding:0}
  .theme button[aria-pressed=true]{background:var(--violet-soft);color:var(--violet)}
  .theme button:hover{color:var(--ink)}
  .theme .ico{width:18px;height:18px}
  h1{font-size:clamp(26px,4.4vw,40px);line-height:1.12;margin:10px 0 0;letter-spacing:-.02em;text-wrap:balance}
  .meta{display:flex;flex-wrap:wrap;gap:6px 16px;align-items:center;margin-top:12px;font-size:14px;color:var(--muted)}
  .meta b{color:var(--ink);font-weight:700}
  .stamp{display:inline-flex;font-size:13px;font-weight:800;border-radius:8px;padding:3px 10px;border:2px solid currentColor;transform:rotate(-2deg)}
  .stamp.draft{color:var(--muted)}.stamp.decided{color:var(--go)}.stamp.dropped{color:var(--stop)}

  /* section nav */
  .toc{display:flex;gap:8px;overflow-x:auto;padding:2px 2px 6px;scrollbar-width:none;margin:2px -2px 0}
  .toc::-webkit-scrollbar{display:none}
  .toc a{flex:none;font-size:14px;font-weight:700;text-decoration:none;color:var(--ink);background:var(--card);border:1px solid var(--line);border-radius:999px;padding:8px 14px;min-height:40px;display:inline-flex;align-items:center}
  .toc a:hover{border-color:var(--violet);color:var(--violet)}
  @media(min-width:900px){.toc{position:sticky;top:0;z-index:5;background:color-mix(in srgb,var(--bg) 88%,transparent);backdrop-filter:blur(8px);padding:10px 2px}}

  .card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:22px;box-shadow:var(--shadow)}
  h2{font-size:21px;line-height:1.2;margin:0 0 6px;display:flex;align-items:center;gap:10px;letter-spacing:-.01em;flex-wrap:wrap}
  h2 .count{font-size:13px;font-weight:800;color:var(--violet);background:var(--violet-soft);border-radius:999px;padding:2px 10px}
  .hint{margin:0 0 16px;color:var(--muted);font-size:14.5px}

  /* verdict */
  .hero{display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:22px;align-items:center;position:relative;overflow:hidden}
  .hero::after{content:"";position:absolute;inset:0;background:radial-gradient(600px 220px at 100% 0,var(--tone-soft),transparent 70%);pointer-events:none}
  .hero > *{position:relative;z-index:1}
  .hero .who{display:flex;flex-direction:column;align-items:center;gap:2px;font-size:13px;font-weight:700;color:var(--muted);text-align:center}
  .label{display:inline-flex;align-items:center;gap:6px;font-size:14px;font-weight:800;color:var(--tone);background:var(--tone-soft);border-radius:999px;padding:4px 12px}
  .verdict{font-size:clamp(22px,3.4vw,30px);font-weight:800;line-height:1.22;margin:10px 0 0;letter-spacing:-.015em;text-wrap:balance;display:block}
  .ring{display:flex;flex-direction:column;align-items:center;width:124px}
  .ring .dial{position:relative;width:112px;height:112px}
  .ring .dial b{position:absolute;inset:0;display:grid;place-items:center;font-size:32px;font-weight:800;font-family:ui-rounded,"SF Pro Rounded",sans-serif;line-height:1;text-align:center}
  .ring .dial b small{display:block;font-size:13px;color:var(--muted);font-weight:700}
  .ring .cap{font-size:12.5px;font-weight:700;color:var(--muted);text-align:center;line-height:1.3;margin-top:6px}
  .tools{display:flex;gap:8px;flex-wrap:wrap;margin-top:16px}
  .btn{display:inline-flex;align-items:center;gap:8px;min-height:44px;padding:0 16px;border-radius:12px;border:1.5px solid var(--line);background:var(--card);color:var(--ink);font-family:inherit;font-size:14.5px;font-weight:700;line-height:1;cursor:pointer}
  .btn:hover{border-color:var(--violet);color:var(--violet)}
  .toast{position:fixed;left:50%;bottom:24px;transform:translate(-50%,20px);opacity:0;background:var(--ink);color:var(--bg);padding:10px 16px;border-radius:12px;font-weight:700;font-size:14px;transition:.25s;pointer-events:none;z-index:10}
  .toast.show{opacity:1;transform:translate(-50%,0)}
  @media(max-width:680px){.hero{grid-template-columns:minmax(0,1fr)}.hero .who{flex-direction:row;gap:10px;justify-content:center}.hero .who .mascot{width:64px;height:64px}.ring{margin:0 auto}.hero .body{text-align:center}.tools{justify-content:center}}

  /* actions */
  .actions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}
  @media(max-width:760px){.actions{grid-template-columns:minmax(0,1fr)}}
  .a{border-radius:18px;padding:16px 18px}
  .a .k{font-size:15px;font-weight:800;display:flex;align-items:center;gap:8px;margin:0 0 6px}
  .a.test{background:var(--violet-soft)} .a.test .k{color:var(--violet)}
  .a.next{background:var(--go-soft)} .a.next .k{color:var(--go)}
  .a.kill{background:var(--stop-soft)} .a.kill .k{color:var(--stop)}

  .grid2{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px}
  @media(max-width:680px){.grid2{grid-template-columns:minmax(0,1fr)}}
  .note{display:flex;gap:14px;align-items:flex-start}
  .note .ic{flex:none;width:40px;height:40px;border-radius:14px;display:grid;place-items:center}
  .note h3{margin:0 0 4px;font-size:16px}

  /* context */
  .ask{margin:0;font-size:16.5px;padding-left:16px;border-left:4px solid var(--violet)}
  .ask.clamp{display:-webkit-box;-webkit-line-clamp:3;-webkit-box-orient:vertical;overflow:hidden}
  .more{background:none;border:0;color:var(--violet);font-family:inherit;font-size:14.5px;font-weight:700;padding:8px 0;min-height:44px;cursor:pointer}
  .facts{list-style:none;margin:16px 0 0;padding:0;display:flex;flex-direction:column;gap:10px}
  .facts li{display:grid;grid-template-columns:104px minmax(0,1fr);gap:10px;align-items:baseline}
  @media(max-width:420px){.facts li{grid-template-columns:minmax(0,1fr);gap:2px}}
  .pill{display:inline-flex;align-items:center;gap:5px;font-size:12.5px;font-weight:800;border-radius:999px;padding:2px 10px;white-space:nowrap;justify-self:start}
  .pill .ico{width:14px;height:14px;stroke-width:3}
  .pill.given,.pill.for,.pill.surv{background:var(--go-soft);color:var(--go)}
  .pill.assumed,.pill.depends{background:var(--test-soft);color:var(--test)}
  .pill.external{background:var(--violet-soft);color:var(--violet)}
  .pill.against,.pill.fell{background:var(--stop-soft);color:var(--stop)}

  /* precedents */
  .prec{display:grid;grid-template-columns:repeat(auto-fill,minmax(250px,1fr));gap:12px}
  .p{border-radius:18px;padding:16px;border:1.5px solid var(--line);background:var(--card-2)}
  .p.failure{border-color:light-dark(#F5CBD2,#5A2A35)} .p.survivor{border-color:light-dark(#BFE9D3,#24533F)}
  .p h3{margin:10px 0 0;font-size:18px;line-height:1.25} .p .yrs{font-size:14px;color:var(--muted);font-weight:600}
  .p p{margin:8px 0 10px;font-size:15px}
  .p .sim{font-size:13px;color:var(--muted);font-weight:700;margin:0 0 4px}
  .chips{display:flex;flex-wrap:wrap;gap:5px}
  .chips > span{font-size:13px;font-weight:600;border-radius:999px;padding:2px 9px;background:var(--violet-soft);color:var(--violet)}
  .chips > .miss{background:light-dark(#F2F0F6,#2A2537);color:var(--muted);text-decoration:line-through}
  .src{display:inline-flex;align-items:center;gap:4px;font-size:14px;font-weight:700;text-decoration:none;margin-top:10px;min-height:32px}
  .src .ico{width:16px;height:16px}
  .src:hover{text-decoration:underline}

  /* crew */
  .tally{display:flex;height:12px;border-radius:999px;overflow:hidden;background:var(--line);margin:4px 0 8px;gap:2px}
  .tally i{display:block;height:100%}
  .legend{display:flex;gap:6px 16px;font-size:14px;font-weight:600;color:var(--muted);margin-bottom:16px;flex-wrap:wrap}
  .legend span{display:inline-flex;align-items:center;gap:6px}
  .legend b{width:10px;height:10px;border-radius:50%;display:inline-block}
  .crew{display:grid;grid-template-columns:repeat(auto-fill,minmax(290px,1fr));gap:12px}
  .m{display:grid;grid-template-columns:86px minmax(0,1fr);gap:12px;align-items:start;border-radius:20px;padding:14px;background:var(--mc-soft);border:1.5px solid var(--mc-line)}
  .m .av{display:flex;flex-direction:column;align-items:center}
  .m .nick{font-weight:800;font-size:15px;font-family:ui-rounded,"SF Pro Rounded",sans-serif}
  .m .head{display:flex;flex-wrap:wrap;align-items:center;gap:6px 8px}
  .m .role{font-family:ui-rounded,"SF Pro Rounded","Nunito",sans-serif;font-size:17px;font-weight:800;color:var(--mc-ink);line-height:1.2;margin:0}
  .m .persona{font-size:13.5px;color:var(--muted);margin:2px 0 8px}
  .bubble{background:var(--card);border-radius:16px;padding:10px 12px;font-size:15px;box-shadow:0 2px 8px -4px rgba(35,28,58,.25);margin:0}
  .bubble .op{display:inline-block;font-size:12.5px;font-weight:700;color:var(--muted);background:light-dark(#F2F0F6,#2A2537);border-radius:999px;padding:0 8px;margin-left:4px}
  @media(max-width:420px){.m{grid-template-columns:64px minmax(0,1fr)}.m .mascot{width:64px;height:64px}}
  :root[data-theme=dark] .m{--mc-ink:var(--ink)!important}
  @media (prefers-color-scheme:dark){:root:not([data-theme=light]) .m{--mc-ink:var(--ink)!important}}

  /* premortem */
  .pm{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:12px}
  .pm li{display:grid;grid-template-columns:34px minmax(0,1fr);gap:12px;align-items:start}
  .pm .n{width:34px;height:34px;border-radius:12px;background:var(--ink);color:var(--bg);display:grid;place-items:center;font-weight:800}
  .pm .sig{display:inline-block;margin-top:4px;font-size:14px;color:var(--muted)}
  .pm .sig b{color:var(--ink)}

  .srcs{margin:0;padding-left:22px;display:flex;flex-direction:column;gap:8px;font-size:15px}
  .srcs a{overflow-wrap:anywhere}
  details.how summary{cursor:pointer;font-weight:800;font-size:18px;list-style:none;display:flex;align-items:center;gap:10px;min-height:44px;font-family:ui-rounded,"SF Pro Rounded","Nunito",sans-serif}
  details.how summary::-webkit-details-marker{display:none}
  details.how summary::after{content:"+";margin-left:auto;font-size:24px;color:var(--violet)}
  details.how[open] summary::after{content:"–"}
  .how-body{margin-top:12px;font-size:15px;display:flex;flex-direction:column;gap:12px}
  .how-body p{margin:0}
  .crewkey{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:6px}
  .crewkey div{display:flex;align-items:center;gap:8px;font-size:14px}
  footer{text-align:center;color:var(--muted);font-size:14px;margin-top:8px;display:flex;flex-direction:column;gap:4px;align-items:center}
  footer a{font-weight:700}

  /* motion */
  @media (prefers-reduced-motion:no-preference){
    .js .reveal{opacity:0;transform:translateY(16px);transition:opacity .55s ease,transform .55s cubic-bezier(.2,.8,.2,1)}
    .js .reveal.in{opacity:1;transform:none}
    .ring .arc{transition:stroke-dasharray 1.3s cubic-bezier(.2,.8,.2,1) .25s}
    .tally i{transition:width 1s cubic-bezier(.2,.8,.2,1) .2s}
    .m{transition:transform .25s ease}
    .m:hover{transform:translateY(-2px)}
  }
  @media print{
    :root{color-scheme:light!important}.theme{display:none!important}
    body{background:#fff;color:#000;padding:0}body::before,.toc,.tools,.toast,.skip{display:none!important}
    .card{box-shadow:none;break-inside:avoid}.reveal{opacity:1!important;transform:none!important}
    *{-webkit-print-color-adjust:exact;print-color-adjust:exact}
    a[href^="http"]::after{content:" (" attr(href) ")";font-size:11px;color:#555;overflow-wrap:anywhere}
  }
</style>
</head>
<body>
<a class="skip" href="#verdict">Skip to verdict</a>
<main id="app"></main>
<div class="toast" role="status" aria-live="polite" id="toast"></div>

<!-- Replace only this JSON when generating a report. -->
<script id="REPORT_DATA" type="application/json">
{
  "lang": "en",
  "title": "Launch same-day grocery delivery in 8 cities at once?",
  "date": "2026-11-25",
  "status": "draft",
  "review_date": "2027-01-31",
  "tone": "test",
  "context": {
    "prompt": "Been there? We run same-day grocery delivery in one city and want to launch in 8 more at once next quarter, with our own warehouses, to get there before competitors.",
    "prepared_by": "Ops team",
    "for": "Leadership meeting"
  },
  "verdict": "Prove one city first, then expand",
  "confidence": 8,
  "agreement": "Volume won't fix negative per-order margins; it multiplies them.",
  "disagreement": "Nova says speed matters against competitors; the rest say speed without economics is exactly how Webvan died.",
  "facts": [
    {"kind":"given","text":"8 new cities, launched together next quarter."},
    {"kind":"given","text":"Own warehouses in each city."},
    {"kind":"assumed","text":"Per-order margin in city 1 is still negative (not stated)."},
    {"kind":"external","text":"Webvan built warehouses city by city before one was profitable."}
  ],
  "key_assumption": "Per-order loss turns positive with route density → test with 4 weeks of route data in city 1.",
  "precedents": [
    {"type":"failure","name":"Webvan","years":"1996–2001","note":"Built warehouses in many cities before one was profitable.","match":["market","mechanism"],"miss":["timing"],"url":"https://en.wikipedia.org/wiki/Webvan"},
    {"type":"survivor","name":"Instacart","years":"2012–","note":"Same market, asset-light: shoppers picked from existing stores.","match":["market","model"],"miss":[]}
  ],
  "advisors": [
    {"role":"devil","name":"Devil's advocate","position":"against","line":"You're Webvan with better branding: losses scale with cities.","opinion":false},
    {"role":"first","name":"First principles","position":"depends","line":"The goal is density per route, not the number of cities.","opinion":false},
    {"role":"expansion","name":"Expansionist","position":"for","line":"First mover in 8 cities could lock in store partnerships.","opinion":true},
    {"role":"outsider","name":"Outsider","position":"depends","line":"Why would I switch from the delivery app I already use?","opinion":true},
    {"role":"executor","name":"Executor","position":"against","line":"Tomorrow: measure cost per order by route, not the average.","opinion":false},
    {"role":"finance","name":"Finance","position":"against","line":"Eight warehouses lock up the cash before demand is proven.","opinion":false}
  ],
  "premortem": [
    {"cause":"Per-order losses grew with each new city.","signal":"contribution margin by city"},
    {"cause":"Warehouse capex locked cash before demand was proven.","signal":"warehouse utilisation under 40%"},
    {"cause":"A competitor with no warehouses undercut prices.","signal":"an Instacart-style partner model in your market"}
  ],
  "next_step": "Pull 4 weeks of order data in city 1 and compute margin by route density.",
  "kill_criterion": "If margin per order isn't positive on the densest routes by 31 Jan, drop the expansion plan.",
  "sources": [{"title":"Webvan (Wikipedia)","url":"https://en.wikipedia.org/wiki/Webvan"}]
}
</script>

<script>
// Been There · The Crew — mascot generator (self-contained SVG, no external assets)
const CREW = {
  devil:     {nick:'Nix',   c:['#FFB0A8','#FF6B6B','#D63E4A'], eyes:'skeptic', mouth:'smirk', arms:'hips',  acc:'horns',   tilt:-4},
  first:     {nick:'Root',  c:['#B5CCFF','#5B8DEF','#3559C2'], eyes:'focus',   mouth:'small', arms:'point', acc:'glasses', tilt:0},
  expansion: {nick:'Nova',  c:['#FFE29A','#FFB547','#E5841A'], eyes:'happy',   mouth:'grin',  arms:'up',    acc:'sparks',  tilt:3},
  outsider:  {nick:'Pip',   c:['#D3F2A6','#93CF55','#5E9F2A'], eyes:'wide',    mouth:'o',     arms:'down',  acc:'question',tilt:8},
  executor:  {nick:'Tack',  c:['#9DECE4','#2EC4B6','#13968A'], eyes:'determined',mouth:'smile',arms:'hold', acc:'hardhat', tilt:0},
  chair:     {nick:'Vera',  c:['#DCCCFF','#9B7BF7','#6C4ED6'], eyes:'calm',    mouth:'smile', arms:'hold',  acc:'gavel',   tilt:0},
  finance:   {nick:'Penny', c:['#A9EFD2','#22B07D','#0F7F57'], eyes:'wink',    mouth:'smile', arms:'hold',  acc:'coin',    tilt:-3},
  risk:      {nick:'Lex',   c:['#C9D3E6','#6B7FA6','#455776'], eyes:'determined',mouth:'flat',arms:'hold', acc:'shield',  tilt:0},
  customer:  {nick:'Mo',    c:['#FFD1EA','#FF8FC7','#E0569D'], eyes:'happy',   mouth:'smile', arms:'hug',   acc:'heart',   tilt:-5},
  technical: {nick:'Bolt',  c:['#FFC9A8','#FF8A4C','#D9602A'], eyes:'focus',   mouth:'grin',  arms:'hold',  acc:'wrench',  tilt:2},
  investor:  {nick:'Cap',   c:['#E8C9A8','#C08457','#8E5A33'], eyes:'monocle', mouth:'smile', arms:'hips',  acc:'tophat',  tilt:0},
  scout:     {nick:'Juno', c:['#A8DCE6','#1F8A9E','#0F5F6E'], eyes:'focus', mouth:'smile', arms:'hold', acc:'compass', tilt:3},
  people:    {nick:'Kin',   c:['#F5CDF8','#DA7FE3','#A94DB3'], eyes:'happy',   mouth:'grin',  arms:'wave',  acc:'bubbles', tilt:-2},
};

function crewKey(name){
  const n = String(name||'').toLowerCase();
  const map = [
    [/devil|abogado|diablo/,'devil'],[/first|primer|principi/,'first'],[/expan/,'expansion'],
    [/scout|explor/,'scout'],[/outsider|forastero|ajeno|externo/,'outsider'],[/execut|ejecut/,'executor'],[/chair|presid|anfitri/,'chair'],
    [/financ|cfo|money/,'finance'],[/risk|riesgo|legal|complian|cumplim/,'risk'],[/customer|cliente|user|usuario/,'customer'],
    [/tech|técn|tecn/,'technical'],[/invest|partner|socio/,'investor'],[/people|personas|rrhh|hr|equipo|talent/,'people'],
  ];
  for (const [re,k] of map) if (re.test(n)) return k;
  return 'chair';
}

function mascot(key, size=120){
  const m = CREW[key] || CREW.chair; const [L,B,D] = m.c; const id = 'g'+key+Math.random().toString(36).slice(2,7);
  const ink = '#2A2140';
  const eye = (x,y)=>`<ellipse cx="${x}" cy="${y}" rx="6.2" ry="7.6" fill="${ink}"/><circle cx="${x+2}" cy="${y-2.8}" r="2.4" fill="#fff"/><circle cx="${x-1.8}" cy="${y+2.6}" r="1" fill="#fff" opacity=".8"/>`;
  const arc = (x,y)=>`<path d="M${x-6} ${y+1} Q${x} ${y-6} ${x+6} ${y+1}" stroke="${ink}" stroke-width="3.2" fill="none" stroke-linecap="round"/>`;
  const brow = (x,y,a)=>`<path d="M${x-6} ${y} L${x+6} ${y+a}" stroke="${ink}" stroke-width="2.8" stroke-linecap="round"/>`;
  let eyes='';
  switch(m.eyes){
    case 'happy': eyes = arc(48,62)+arc(74,62); break;
    case 'calm': eyes = `<path d="M42 62 Q48 67 54 62" stroke="${ink}" stroke-width="3.2" fill="none" stroke-linecap="round"/><path d="M68 62 Q74 67 80 62" stroke="${ink}" stroke-width="3.2" fill="none" stroke-linecap="round"/>`; break;
    case 'wink': eyes = eye(48,62)+arc(74,63); break;
    case 'wide': eyes = `<circle cx="48" cy="61" r="9" fill="#fff"/><circle cx="74" cy="61" r="9" fill="#fff"/>`+eye(49,62)+eye(75,62); break;
    case 'skeptic': eyes = `<ellipse cx="48" cy="63" rx="6" ry="5" fill="${ink}"/><circle cx="50" cy="61.5" r="1.8" fill="#fff"/>`+eye(74,62)+brow(48,54,2)+`<path d="M68 51 Q74 46 80 50" stroke="${ink}" stroke-width="2.8" fill="none" stroke-linecap="round"/>`; break;
    case 'determined': eyes = eye(48,63)+eye(74,63)+brow(48,52,3)+brow(74,55,-3); break;
    case 'monocle': eyes = eye(48,62)+eye(74,62)+`<circle cx="74" cy="62" r="11" fill="#fff" fill-opacity=".25" stroke="#C9A227" stroke-width="2.6"/><path d="M84 66 Q90 80 86 92" stroke="#C9A227" stroke-width="1.5" fill="none"/>`; break;
    case 'focus': default: eyes = eye(48,62)+eye(74,62);
  }
  const mouths = {
    smile:`<path d="M54 76 Q61 83 68 76" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    small:`<path d="M57 77 Q61 80 65 77" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    grin:`<path d="M52 74 Q61 74 70 74 Q68 87 61 87 Q54 87 52 74Z" fill="${ink}"/><path d="M56 82 Q61 79 66 82 Q64 86 61 86 Q58 86 56 82Z" fill="#FF7A8A"/>`,
    smirk:`<path d="M54 78 Q62 81 69 74" stroke="${ink}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    o:`<ellipse cx="61" cy="79" rx="4" ry="5" fill="${ink}"/>`,
    flat:`<path d="M55 78 L67 78" stroke="${ink}" stroke-width="3" stroke-linecap="round"/>`,
  };
  const armShape = (x,y,r)=>`<ellipse cx="${x}" cy="${y}" rx="7" ry="12" fill="url(#${id}b)" transform="rotate(${r} ${x} ${y})"/>`;
  const arms = {
    down: armShape(24,76,20)+armShape(98,76,-20),
    hips: armShape(25,80,-35)+armShape(97,80,35),
    up: armShape(22,50,40)+armShape(100,50,-40),
    point: armShape(24,78,20)+armShape(98,50,-25)+`<circle cx="103" cy="39" r="3.6" fill="${B}"/>`,
    hold: armShape(25,78,25)+armShape(92,80,-55),
    hug: armShape(36,84,-60)+armShape(86,84,60),
    wave: armShape(24,78,20)+armShape(100,48,-30),
  };
  const accs = {
    horns:`<path d="M40 34 Q36 20 44 18 Q44 28 48 32Z" fill="${D}"/><path d="M82 34 Q86 20 78 18 Q78 28 74 32Z" fill="${D}"/><path d="M98 96 Q110 98 108 86 l4 -3 -6 -1" stroke="${D}" stroke-width="3" fill="none" stroke-linecap="round"/>`,
    glasses:`<circle cx="48" cy="62" r="10" fill="#fff" fill-opacity=".18" stroke="${ink}" stroke-width="2.4"/><circle cx="74" cy="62" r="10" fill="#fff" fill-opacity=".18" stroke="${ink}" stroke-width="2.4"/><path d="M58 61 Q61 58 64 61" stroke="${ink}" stroke-width="2.4" fill="none"/><g transform="translate(96 20)" opacity=".9"><ellipse rx="11" ry="4" fill="none" stroke="${D}" stroke-width="1.8"/><ellipse rx="11" ry="4" fill="none" stroke="${D}" stroke-width="1.8" transform="rotate(60)"/><ellipse rx="11" ry="4" fill="none" stroke="${D}" stroke-width="1.8" transform="rotate(-60)"/><circle r="2.6" fill="${D}"/></g>`,
    sparks:`<g stroke="#FFC83D" stroke-width="3.4" stroke-linecap="round"><path d="M14 30 l-6 -6"/><path d="M22 22 l-2 -9"/><path d="M106 30 l6 -6"/><path d="M98 22 l2 -9"/></g><path d="M104 6 l2 5 5 2 -5 2 -2 5 -2 -5 -5 -2 5 -2z" fill="#FFC83D"/><path d="M16 4 l1.5 4 4 1.5 -4 1.5 -1.5 4 -1.5 -4 -4 -1.5 4 -1.5z" fill="#FFC83D"/>`,
    question:`<text x="92" y="30" font-family="Arial Rounded MT Bold,Arial,sans-serif" font-weight="900" font-size="26" fill="${D}">?</text><path d="M60 30 Q56 18 64 12 Q66 22 60 30Z" fill="#5E9F2A"/>`,
    hardhat:`<path d="M30 42 Q31 18 61 17 Q91 18 92 42Z" fill="#FFC83D"/><path d="M26 42 h70 q3 0 3 3 v1 q0 3 -3 3 h-70 q-3 0 -3 -3 v-1 q0 -3 3 -3z" fill="#F2A900"/><rect x="57" y="18" width="8" height="24" rx="3" fill="#F2A900"/><g transform="translate(86 74) rotate(-12)"><rect x="0" y="0" width="22" height="28" rx="3" fill="#fff" stroke="${D}" stroke-width="2"/><rect x="6" y="-3" width="10" height="6" rx="2" fill="${D}"/><path d="M5 11 l3 3 6 -6 M5 20 l3 3 6 -6" stroke="#22B07D" stroke-width="2.2" fill="none" stroke-linecap="round"/></g>`,
    gavel:`<g transform="translate(92 70) rotate(-35)"><rect x="-3" y="0" width="6" height="26" rx="3" fill="#8E5A33"/><rect x="-11" y="-9" width="22" height="11" rx="4" fill="#A86B3C"/></g><path d="M47 30 l3 -14 6 8 5 -10 5 10 6 -8 3 14z" fill="#FFC83D" stroke="#E5A100" stroke-width="1.5" stroke-linejoin="round"/>`,
    coin:`<g transform="translate(96 82)"><circle r="12" fill="#FFC83D" stroke="#E5A100" stroke-width="2.5"/><text y="5.5" text-anchor="middle" font-family="Arial,sans-serif" font-weight="900" font-size="15" fill="#B57F00">€</text></g><circle cx="104" cy="56" r="5" fill="#FFC83D" stroke="#E5A100" stroke-width="1.5"/>`,
    shield:`<g transform="translate(96 76)"><path d="M0 -14 L13 -9 Q13 8 0 16 Q-13 8 -13 -9Z" fill="#4C8DF6" stroke="#2C5EB8" stroke-width="2"/><path d="M-5 0 l4 4 7 -8" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/></g>`,
    heart:`<path d="M61 100 C44 88 44 76 53 74 C57 73 60 76 61 79 C62 76 65 73 69 74 C78 76 78 88 61 100Z" fill="#FF4F7B" stroke="#D93460" stroke-width="1.5"/><path d="M98 22 c-4 -6 -12 -1 -6 6 l6 6 6 -6 c6 -7 -2 -12 -6 -6z" fill="#FF4F7B" opacity=".8"/>`,
    wrench:`<g transform="translate(98 74) rotate(35) scale(1.25)"><rect x="-3" y="-2" width="6" height="26" rx="3" fill="#8A94A6"/><path d="M-9 -8 a9 9 0 1 0 18 0 l-5 0 l0 5 l-8 0 l0 -5z" fill="#A9B2C3"/></g>`,
    tophat:`<rect x="38" y="6" width="46" height="26" rx="4" fill="#2A2140"/><rect x="38" y="24" width="46" height="5" fill="#C9A227"/><rect x="30" y="30" width="62" height="6" rx="3" fill="#2A2140"/>`,
    compass:`<g transform="translate(96 78)"><circle r="13" fill="#fff" stroke="${D}" stroke-width="2.6"/><circle r="9.5" fill="none" stroke="${L}" stroke-width="1.2"/><path d="M0 -9 L3.2 0 L0 1.5 L-3.2 0Z" fill="#E2475A"/><path d="M0 9 L3.2 0 L0 -1.5 L-3.2 0Z" fill="#8A94A6"/><circle r="1.8" fill="${ink}"/><rect x="-2.5" y="-17" width="5" height="4.5" rx="1.5" fill="${D}"/></g><g fill="${D}" opacity=".55"><circle cx="16" cy="30" r="2"/><circle cx="24" cy="23" r="2"/><circle cx="34" cy="19" r="2"/></g><path d="M8 38 l3 -7 3 7 -3 -2z" fill="#E2475A" opacity=".85"/>`,
    bubbles:`<g transform="translate(92 14)"><rect x="0" y="0" width="22" height="15" rx="6" fill="#fff" stroke="${D}" stroke-width="2"/><path d="M5 15 l-2 6 7 -6z" fill="#fff" stroke="${D}" stroke-width="2" stroke-linejoin="round"/><circle cx="6" cy="7.5" r="1.6" fill="${D}"/><circle cx="11" cy="7.5" r="1.6" fill="${D}"/><circle cx="16" cy="7.5" r="1.6" fill="${D}"/></g><g transform="translate(6 22)"><rect width="16" height="12" rx="5" fill="#fff" stroke="${D}" stroke-width="2"/><path d="M5 7 q3 -4 6 0" stroke="#FF4F7B" stroke-width="2" fill="none"/></g>`,
  };
  const back = (m.acc==='tophat'||m.acc==='hardhat'||m.acc==='gavel') ? '' : `<path d="M54 30 Q50 14 62 10 Q60 20 68 26 Q64 30 54 30Z" fill="url(#${id}b)"/>`;
  return `<svg class="mascot" viewBox="0 0 122 122" width="${size}" height="${size}" role="img" aria-label="${m.nick}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <radialGradient id="${id}b" cx="36%" cy="30%" r="78%"><stop offset="0" stop-color="${L}"/><stop offset=".55" stop-color="${B}"/><stop offset="1" stop-color="${D}"/></radialGradient>
    <radialGradient id="${id}s" cx="50%" cy="50%" r="50%"><stop offset="0" stop-color="#2A2140" stop-opacity=".22"/><stop offset="1" stop-color="#2A2140" stop-opacity="0"/></radialGradient>
  </defs>
  <ellipse class="sh" cx="61" cy="112" rx="36" ry="6" fill="url(#${id}s)"/>
  <g class="bob"><g transform="rotate(${m.tilt} 61 70)">
    <ellipse cx="48" cy="104" rx="9" ry="6" fill="${D}"/><ellipse cx="74" cy="104" rx="9" ry="6" fill="${D}"/>
    ${arms[m.arms]}
    ${back}
    <path d="M61 26 C88 26 100 46 100 68 C100 92 84 104 61 104 C38 104 22 92 22 68 C22 46 34 26 61 26Z" fill="url(#${id}b)"/>
    <ellipse cx="44" cy="40" rx="11" ry="6" fill="#fff" opacity=".55" transform="rotate(-28 44 40)"/>
    <ellipse cx="38" cy="74" rx="6.5" ry="4" fill="#FF7FA0" opacity=".4"/><ellipse cx="84" cy="74" rx="6.5" ry="4" fill="#FF7FA0" opacity=".4"/>
    <g class="eyes">${eyes}</g>${mouths[m.mouth]}
    ${accs[m.acc]||''}
  </g></g></svg>`;
}

// Motion for mascots (bob, blink, hop). Inject once; respects reduced motion.
const MASCOT_CSS = `
.mascot{overflow:visible}
.mascot .bob,.mascot .sh,.mascot .eyes{transform-box:fill-box;transform-origin:50% 100%}
.mascot .eyes{transform-origin:50% 50%}
@keyframes bt-bob{0%,100%{transform:translateY(0)}50%{transform:translateY(-4px)}}
@keyframes bt-sh{0%,100%{transform:scaleX(1);opacity:1}50%{transform:scaleX(.86);opacity:.75}}
@keyframes bt-blink{0%,92%,100%{transform:scaleY(1)}95%{transform:scaleY(.1)}}
@keyframes bt-hop{0%{transform:translateY(0) scale(1)}30%{transform:translateY(-14px) scale(1.04,.96)}55%{transform:translateY(0) scale(1.06,.92)}75%{transform:translateY(-4px)}100%{transform:translateY(0)}}
@media (prefers-reduced-motion:no-preference){
  .mascot .bob{animation:bt-bob 3.4s ease-in-out infinite;animation-delay:var(--d,0s)}
  .mascot .sh{animation:bt-sh 3.4s ease-in-out infinite;animation-delay:var(--d,0s)}
  .mascot .eyes{animation:bt-blink 4.6s infinite;animation-delay:var(--d,0s)}
  .hop:hover .mascot .bob,.hop:focus-within .mascot .bob,.hop.tap .mascot .bob{animation:bt-hop .7s ease-out}
}`;
(function(){ if (typeof document==='undefined' || document.getElementById('bt-mascot-css')) return;
  const st=document.createElement('style'); st.id='bt-mascot-css'; st.textContent=MASCOT_CSS; document.head.appendChild(st);
  document.addEventListener('pointerdown', e => { const h=e.target.closest && e.target.closest('.hop'); if(!h) return;
    h.classList.remove('tap'); void h.offsetWidth; h.classList.add('tap'); setTimeout(()=>h.classList.remove('tap'),750); });
})();

</script>
<script>
{
  const d = JSON.parse(document.getElementById('REPORT_DATA').textContent);
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const safeUrl = u => /^https?:\/\//i.test(String(u||'')) ? esc(u) : '';
  const T = {
    en:{skip:'Skip to verdict',themeLabel:'Appearance',themes:{auto:'Automatic (device)',light:'Light',dark:'Dark'},navLabel:'Sections',nav:{verdict:'Verdict',todo:'What to do',ctx:'The question',prec:'Precedents',crew:'The Crew',pm:'Pre-mortem',src:'Sources'},
        crew:'The Crew',crewHint:'Each member answered alone, before seeing the others.',agree:'Where the Crew agrees',dis:'Real disagreement',
        prec:'Who has been there',precHint:'Companies that tried something similar. Purple tags: how they resemble this plan. Crossed out: how they differ.',
        fell:'Fell',surv:'Survived',sim:'Similar in:',not:'not',src:'Source',none:'No precedent close enough. Better none than a forced one.',
        pm:'Pre-mortem',pmHint:"It's 12 months later and the plan failed. The most likely reasons, and the signal to watch for each.",signal:'Watch',
        todo:'What to do now',test:'Assumption to test',next:'Next 48 hours',kill:'Kill criterion',
        conf:'Confidence',confCap:'how sure the verdict is',chairs:'chairs the Crew',
        for:'For',against:'Against',depends:'Depends',op:'opinion',
        ctx:'The question',more:'Show more',less:'Show less',by:'Prepared by',forr:'For',review:'Review on',status:{draft:'Draft',decided:'Decided',dropped:'Dropped'},
        facts:'Starting facts',kinds:{given:'Given',assumed:'Assumed',external:'Checked'},srcs:'Sources',
        copy:'Copy summary',copied:'Summary copied',copyFail:'Select the text to copy it',
        roles:{devil:"Devil's advocate",first:'First principles',expansion:'Expansionist',outsider:'Outsider',executor:'Executor',chair:'Chair',finance:'Finance',risk:'Risk & compliance',customer:'Customer',technical:'Technical',investor:'Investor / partner',people:'People',scout:'Idea scout'},
        persona:{devil:'Looks for how it dies',first:'Asks what problem you really solve',expansion:'Sees the upside others miss',outsider:'Asks what a newcomer would ask',executor:'What happens tomorrow at 9:00',chair:'Weighs arguments, not votes',finance:'Follows the money',risk:'Reads the small print',customer:'Speaks for the buyer',technical:'Checks it can be built',investor:'Thinks like whoever funds it',people:'Thinks about the team',scout:'Turns the idea into testable bets'},
        tone:{go:'Go',stop:"Don't",test:'Test first'},
        how:'How to read this report',
        howText:['Been There checks a plan against companies that already tried something similar. Fell marks those that failed the same way; Survived marks those that faced the same trap and made it.','The Crew answers independently. Points without evidence are tagged opinion. Vera, the chair, weighs arguments, not votes. Confidence is how sure the verdict is, not the odds of success.','Starting facts separate what was given, what was assumed and what was checked against outside sources.'],
        made:'Made with',what:'What is this?',foot:'Precedents are evidence, not predictions.'},
    es:{skip:'Ir al veredicto',themeLabel:'Apariencia',themes:{auto:'Automático (dispositivo)',light:'Claro',dark:'Oscuro'},navLabel:'Secciones',nav:{verdict:'Veredicto',todo:'Qué hacer',ctx:'Planteamiento',prec:'Precedentes',crew:'La Pandilla',pm:'Pre-mortem',src:'Fuentes'},
        crew:'La Pandilla',crewHint:'Cada miembro opinó por separado, sin ver lo que decían los demás.',agree:'En qué coinciden',dis:'Desacuerdo real',
        prec:'Quién ya pasó por aquí',precHint:'Empresas que intentaron algo parecido. Etiquetas moradas: en qué se parecen a este plan. Tachadas: en qué no.',
        fell:'Cayó',surv:'Sobrevivió',sim:'Se parece en:',not:'no',src:'Fuente',none:'Ningún precedente se parece lo suficiente. Mejor ninguno que uno forzado.',
        pm:'Pre-mortem',pmHint:'Han pasado 12 meses y el plan fracasó. Las causas más probables y la señal que avisa de cada una.',signal:'Vigila',
        todo:'Qué hacer ahora',test:'Supuesto a comprobar',next:'Próximas 48 horas',kill:'Criterio de abandono',
        conf:'Confianza',confCap:'lo seguro que es el veredicto',chairs:'preside la Pandilla',
        for:'A favor',against:'En contra',depends:'Depende',op:'opinión',
        ctx:'El planteamiento',more:'Ver más',less:'Ver menos',by:'Preparado por',forr:'Para',review:'Revisar el',status:{draft:'Borrador',decided:'Decidido',dropped:'Descartado'},
        facts:'Datos de partida',kinds:{given:'Dato',assumed:'Supuesto',external:'Verificado'},srcs:'Fuentes',
        copy:'Copiar resumen',copied:'Resumen copiado',copyFail:'Selecciona el texto para copiarlo',
        roles:{devil:'Abogado del diablo',first:'Primeros principios',expansion:'Expansionista',outsider:'Forastero',executor:'Ejecutor',chair:'Presidencia',finance:'Finanzas',risk:'Riesgo y cumplimiento',customer:'Cliente',technical:'Técnico',investor:'Inversor / socio',people:'Personas',scout:'Exploradora'},
        persona:{devil:'Busca cómo puede morir el plan',first:'Pregunta qué problema resuelves de verdad',expansion:'Ve el potencial que otros no ven',outsider:'Pregunta lo que preguntaría alguien de fuera',executor:'Qué pasa mañana a las 9:00',chair:'Pesa argumentos, no votos',finance:'Sigue el dinero',risk:'Lee la letra pequeña',customer:'Habla por el cliente',technical:'Comprueba que se puede construir',investor:'Piensa como quien pone el dinero',people:'Piensa en el equipo',scout:'Convierte la idea en apuestas comprobables'},
        tone:{go:'Adelante',stop:'No lo hagas',test:'Primero, prueba'},
        how:'Cómo leer este informe',
        howText:['Been There compara un plan con empresas que ya intentaron algo parecido. Cayó marca las que fracasaron por el mismo motivo; Sobrevivió, las que se enfrentaron a la misma trampa y salieron adelante.','La Pandilla opina por separado. Lo que no se apoya en datos lleva la etiqueta opinión. Vera, que preside, pesa argumentos, no votos. La confianza mide lo seguro que es el veredicto, no la probabilidad de éxito.','Los datos de partida distinguen lo que se dio, lo que se supuso y lo que se comprobó con fuentes externas.'],
        made:'Hecho con',what:'¿Qué es esto?',foot:'Los precedentes son evidencias, no predicciones.'}
  };
  const lang = T[d.lang] ? d.lang : 'en', t = T[lang];
  const I = {
    check:'<path d="M20 6 9 17l-5-5"/>', zap:'<path d="M13 2 3 14h9l-1 8 10-12h-9l1-8z"/>',
    target:'<circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>', stop:'<path d="M8 2h8l6 6v8l-6 6H8l-6-6V8z"/><path d="M15 9l-6 6M9 9l6 6"/>',
    copy:'<rect x="9" y="9" width="12" height="12" rx="2"/><path d="M5 15V5a2 2 0 0 1 2-2h10"/>', ext:'<path d="M14 4h6v6M20 4 10 14M19 13v6a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V6a1 1 0 0 1 1-1h6"/>',
    flask:'<path d="M9 3h6M10 3v6L4 19a1 1 0 0 0 .9 1.5h14.2A1 1 0 0 0 20 19l-6-10V3"/>', x:'<path d="M18 6 6 18M6 6l12 12"/>',
    sun:'<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/>', moon:'<path d="M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8z"/>', auto:'<rect x="3" y="4" width="18" height="13" rx="2"/><path d="M8 21h8M12 17v4"/>',
    rocket:'<path d="M5 15c-1.5 1.3-2 5-2 5s3.7-.5 5-2c.7-.8.7-2 0-2.8a2 2 0 0 0-3 0z"/><path d="M12 15 9 12a22 22 0 0 1 2-4 13 13 0 0 1 11-6c0 2.7-.8 7.5-6 11a22 22 0 0 1-4 2z"/>'
  };
  const ico = k => `<svg class="ico" viewBox="0 0 24 24" aria-hidden="true" focusable="false">${I[k]}</svg>`;
  const tones = {go:['var(--go)','var(--go-soft)','var(--ring-go)','rocket'],stop:['var(--stop)','var(--stop-soft)','var(--ring-stop)','x'],test:['var(--test)','var(--test-soft)','var(--ring-test)','flask']};
  const tk = tones[d.tone] ? d.tone : 'test', tone = tones[tk];
  const conf = Math.max(0,Math.min(10,Math.round(+d.confidence||0))), C = 2*Math.PI*48;
  const fmtDate = s => { const x = new Date(String(s)+'T12:00:00'); return isNaN(x) ? esc(s) : esc(x.toLocaleDateString(lang,{day:'numeric',month:'short',year:'numeric'})); };
  const mq = (k,sz) => mascot(k,sz).replace(/ role="img" aria-label="[^"]*"/,' aria-hidden="true" focusable="false"');
  const adv = (d.advisors||[]).map(a => ({...a, key:(a.role && CREW[a.role]) ? a.role : crewKey(a.name)}));
  const cnt = {for:0,depends:0,against:0}; adv.forEach(a => { if (a.position in cnt) cnt[a.position]++; });
  const tot = adv.length || 1, cx = d.context || {}, st = d.status ? (t.status[d.status] || d.status) : '';
  const posVar = k => k==='for'?'var(--ring-go)':k==='against'?'var(--ring-stop)':'var(--ring-test)';
  const pm = (d.premortem||[]).map(x => typeof x === 'string' ? {cause:x} : x);
  const prec = d.precedents||[], facts = d.facts||[], srcs = d.sources||[];
  const sections = [['verdict',1],['todo',1],['ctx',cx.prompt||facts.length],['prec',1],['crew',adv.length],['pm',pm.length],['src',srcs.length]].filter(s=>s[1]);
  document.documentElement.lang = lang;
  document.title = 'Been There · ' + d.title;
  document.querySelector('.skip').textContent = t.skip;

  document.getElementById('app').innerHTML = `
    <header>
      <div class="brand"><span class="dot" aria-hidden="true"></span><a href="https://koaling.github.io/been-there/">Been There</a>${d.date?`<time datetime="${esc(d.date)}">${fmtDate(d.date)}</time>`:'<span style="margin-left:auto"></span>'}<div class="theme" role="group" aria-label="${esc(t.themeLabel)}">${['light','auto','dark'].map(m=>`<button type="button" data-theme-set="${m}" aria-pressed="false" aria-label="${esc(t.themes[m])}" title="${esc(t.themes[m])}">${ico(m==='light'?'sun':m==='dark'?'moon':'auto')}</button>`).join('')}</div></div>
      <h1>${esc(d.title)}</h1>
      ${(st||cx.prepared_by||cx.for||d.review_date)?`<div class="meta">${st?`<span class="stamp ${esc(d.status)}">${esc(st)}</span>`:''}${cx.prepared_by?`<span>${esc(t.by)}: <b>${esc(cx.prepared_by)}</b></span>`:''}${cx.for?`<span>${esc(t.forr)}: <b>${esc(cx.for)}</b></span>`:''}${d.review_date?`<span>${esc(t.review)}: <b><time datetime="${esc(d.review_date)}">${fmtDate(d.review_date)}</time></b></span>`:''}</div>`:''}
    </header>
    <nav class="toc" aria-label="${esc(t.navLabel)}">${sections.map(s=>`<a href="#${s[0]}">${esc(t.nav[s[0]])}</a>`).join('')}</nav>

    <section class="card hero" id="verdict" aria-labelledby="v-h" style="--tone:${tone[0]};--tone-soft:${tone[1]}">
      <div class="who hop">${mq('chair',96)}<span>Vera · ${esc(t.chairs)}</span></div>
      <div class="body">
        <span class="label">${ico(tone[3])}${esc(t.tone[tk])}</span>
        <h2 class="verdict display" id="v-h">${esc(d.verdict)}</h2>
        <div class="tools"><button class="btn" id="copyBtn" type="button">${ico('copy')}${esc(t.copy)}</button></div>
      </div>
      <div class="ring" role="img" aria-label="${esc(t.conf)}: ${conf}/10">
        <div class="dial" aria-hidden="true"><svg viewBox="0 0 112 112" width="112" height="112">
          <circle cx="56" cy="56" r="48" fill="none" stroke="var(--line)" stroke-width="10"/>
          <circle class="arc" data-to="${C*conf/10}" cx="56" cy="56" r="48" fill="none" stroke="${tone[2]}" stroke-width="10" stroke-linecap="round" stroke-dasharray="${C*conf/10} ${C}" transform="rotate(-90 56 56)"/></svg>
          <b><span>${conf}<small>/10</small></span></b></div>
        <div class="cap" aria-hidden="true">${esc(t.conf)}<br>${esc(t.confCap)}</div>
      </div>
    </section>

    <section class="card" id="todo" aria-labelledby="todo-h"><h2 id="todo-h">${esc(t.todo)}</h2>
      <div class="actions">
        <div class="a test"><h3 class="k">${ico('target')}${esc(t.test)}</h3>${esc(d.key_assumption)}</div>
        <div class="a next"><h3 class="k">${ico('clock')}${esc(t.next)}</h3>${esc(d.next_step)}</div>
        <div class="a kill"><h3 class="k">${ico('stop')}${esc(t.kill)}</h3>${esc(d.kill_criterion)}</div>
      </div></section>

    <div class="grid2">
      <section class="card note"><div class="ic" style="background:var(--go-soft);color:var(--go)">${ico('check')}</div><div><h3>${esc(t.agree)}</h3>${esc(d.agreement)}</div></section>
      <section class="card note"><div class="ic" style="background:var(--test-soft);color:var(--test)">${ico('zap')}</div><div><h3>${esc(t.dis)}</h3>${esc(d.disagreement)}</div></section>
    </div>

    ${(cx.prompt||facts.length)?`<section class="card" id="ctx" aria-labelledby="ctx-h"><h2 id="ctx-h">${esc(t.ctx)}</h2>
      ${cx.prompt?`<p class="ask clamp" id="ask">${esc(cx.prompt)}</p><button class="more" id="moreBtn" type="button" aria-expanded="false" aria-controls="ask" hidden>${esc(t.more)}</button>`:''}
      ${facts.length?`<h3 class="sr">${esc(t.facts)}</h3><ul class="facts">${facts.map(f=>`<li><span class="pill ${esc(f.kind)}">${esc(t.kinds[f.kind]||f.kind)}</span><span>${esc(f.text)}</span></li>`).join('')}</ul>`:''}
    </section>`:''}

    <section class="card" id="prec" aria-labelledby="prec-h"><h2 id="prec-h">${esc(t.prec)} <span class="count">${prec.length}</span></h2>
      ${prec.length?`<p class="hint">${esc(t.precHint)}</p><div class="prec">${prec.map(p=>{const s=p.type==='survivor', u=safeUrl(p.url); return `
        <article class="p ${s?'survivor':'failure'}">
          <span class="pill ${s?'surv':'fell'}">${ico(s?'check':'x')}${esc(s?t.surv:t.fell)}</span>
          <h3>${esc(p.name)}</h3><div class="yrs">${esc(p.years)}</div>
          <p>${esc(p.note)}</p>
          ${((p.match||[]).length||(p.miss||[]).length)?`<p class="sim">${esc(t.sim)}</p><div class="chips">${(p.match||[]).map(m=>`<span>${esc(m)}</span>`).join('')}${(p.miss||[]).map(m=>`<span class="miss"><span class="sr">(${esc(t.not)}) </span>${esc(m)}</span>`).join('')}</div>`:''}
          ${u?`<a class="src" href="${u}" target="_blank" rel="noopener">${esc(t.src)} ${ico('ext')}<span class="sr"> (${esc(p.name)})</span></a>`:''}
        </article>`}).join('')}</div>`:`<p class="hint" style="margin:0">${esc(t.none)}</p>`}
    </section>

    ${adv.length?`<section class="card" id="crew" aria-labelledby="crew-h"><h2 id="crew-h">${esc(t.crew)} <span class="count">${adv.length}</span></h2>
      <p class="hint">${esc(t.crewHint)}</p>
      <div class="tally" aria-hidden="true">${['for','depends','against'].filter(k=>cnt[k]).map(k=>`<i data-to="${cnt[k]/tot*100}%" style="width:${cnt[k]/tot*100}%;background:${posVar(k)}"></i>`).join('')}</div>
      <div class="legend">${['for','depends','against'].map(k=>`<span><b style="background:${posVar(k)}" aria-hidden="true"></b>${esc(t[k])}: ${cnt[k]}</span>`).join('')}</div>
      <div class="crew">${adv.map((a,i)=>{const c=CREW[a.key]; return `
        <article class="m hop" style="--d:${(-i*0.55).toFixed(2)}s;--mc-soft:${c.c[1]}1F;--mc-line:${c.c[1]}40;--mc-ink:${c.c[2]}">
          <div class="av">${mq(a.key,84)}<div class="nick" aria-hidden="true">${esc(c.nick)}</div></div>
          <div><div class="head"><h3 class="role"><span class="sr">${esc(c.nick)}, </span>${esc(t.roles[a.key]||a.name)}</h3><span class="pill ${esc(a.position)}">${esc(t[a.position]||a.position)}</span></div>
            <p class="persona">${esc(t.persona[a.key]||'')}</p>
            <p class="bubble">${esc(a.line)}${a.opinion?`<span class="op">${esc(t.op)}</span>`:''}</p></div>
        </article>`}).join('')}</div>
    </section>`:''}

    ${pm.length?`<section class="card" id="pm" aria-labelledby="pm-h"><h2 id="pm-h">${esc(t.pm)}</h2><p class="hint">${esc(t.pmHint)}</p>
      <ol class="pm">${pm.map((x,i)=>`<li><span class="n" aria-hidden="true">${i+1}</span><div>${esc(x.cause)}${x.signal?`<br><span class="sig"><b>${esc(t.signal)}:</b> ${esc(x.signal)}</span>`:''}</div></li>`).join('')}</ol></section>`:''}

    ${srcs.length?`<section class="card" id="src" aria-labelledby="src-h"><h2 id="src-h">${esc(t.srcs)}</h2><ol class="srcs">${srcs.map(s=>{const u=safeUrl(s.url); return `<li>${u?`<a href="${u}" target="_blank" rel="noopener">${esc(s.title||s.url)}</a>`:esc(s.title)}</li>`}).join('')}</ol></section>`:''}

    <section class="card"><details class="how"><summary>${esc(t.how)}</summary><div class="how-body">
      ${t.howText.map(x=>`<p>${esc(x)}</p>`).join('')}
      <div class="crewkey">${Object.keys(CREW).map(k=>`<div>${mq(k,40)}<span><b>${esc(CREW[k].nick)}</b> · ${esc(t.roles[k])}</span></div>`).join('')}</div>
    </div></details></section>

    <footer><span>${esc(t.foot)}</span><span>${esc(t.made)} <a href="https://github.com/koaling/been-there">Been There</a> · <a href="https://koaling.github.io/been-there/">${esc(t.what)}</a></span></footer>`;

  /* Appearance: automatic by default, light/dark on demand (remembered per browser) */
  {
    const root = document.documentElement, KEY = 'been-there-theme';
    const apply = m => { if (m === 'light' || m === 'dark') root.setAttribute('data-theme', m); else root.removeAttribute('data-theme');
      document.querySelectorAll('[data-theme-set]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.themeSet === m))); };
    let mode = 'auto'; try { mode = localStorage.getItem(KEY) || 'auto'; } catch (e) {}
    apply(mode);
    document.querySelectorAll('[data-theme-set]').forEach(b => b.addEventListener('click', () => {
      mode = b.dataset.themeSet; apply(mode); try { localStorage.setItem(KEY, mode); } catch (e) {} }));
  }

  /* "Show more" only when the question is actually clamped */
  const ask = document.getElementById('ask'), more = document.getElementById('moreBtn');
  if (ask && more) {
    requestAnimationFrame(() => { if (ask.scrollHeight > ask.clientHeight + 2) more.hidden = false; });
    more.addEventListener('click', () => { const open = !ask.classList.toggle('clamp'); more.setAttribute('aria-expanded', String(open)); more.textContent = open ? t.less : t.more; });
  }

  /* Copy a plain-text summary for chat or email */
  const toast = msg => { const el = document.getElementById('toast'); el.textContent = msg; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 2200); };
  document.getElementById('copyBtn').addEventListener('click', async () => {
    const lines = [d.title, `${t.tone[tk]}: ${d.verdict} (${t.conf.toLowerCase()} ${conf}/10)`, '', `${t.test}: ${d.key_assumption}`, `${t.next}: ${d.next_step}`, `${t.kill}: ${d.kill_criterion}`];
    if (prec.length) lines.push('', `${t.prec}: ` + prec.map(p => `${p.type==='survivor'?'✓':'✕'} ${p.name}`).join(', '));
    lines.push('', `${t.made} Been There · https://koaling.github.io/been-there/`);
    try { await navigator.clipboard.writeText(lines.join('\n')); toast(t.copied); } catch (e) { toast(t.copyFail); }
  });

  /* Reveal on scroll; ring and tally fill when seen */
  const app = document.getElementById('app');
  app.querySelectorAll(':scope > section, :scope > .grid2 > section, .p, .m').forEach(el => el.classList.add('reveal'));
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  if (!reduce && 'IntersectionObserver' in window) {
    document.documentElement.classList.add('js');
    app.querySelectorAll('.ring .arc').forEach(a => a.setAttribute('stroke-dasharray', '0 ' + C));
    app.querySelectorAll('.tally i').forEach(b => b.style.width = '0');
    const io = new IntersectionObserver(es => es.forEach(e => {
      if (!e.isIntersecting) return; const el = e.target; el.classList.add('in'); io.unobserve(el);
      el.querySelectorAll('.arc').forEach(a => requestAnimationFrame(() => a.setAttribute('stroke-dasharray', a.dataset.to + ' ' + C)));
      el.querySelectorAll('.tally i').forEach(b => requestAnimationFrame(() => b.style.width = b.dataset.to));
    }), {threshold:.1});
    let n = 0; app.querySelectorAll('.reveal').forEach(el => { if (el.matches('.p,.m')) el.style.transitionDelay = ((n++ % 4) * 70) + 'ms'; else n = 0; io.observe(el); });
    window.addEventListener('beforeprint', () => app.querySelectorAll('.reveal').forEach(el => el.classList.add('in')));
  }
}
</script>
</body>
</html>
```
